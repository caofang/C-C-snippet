qshttpd
=======

qshttpd is a HTTP server I wrote back in 2007 when I was learning to program with C. The code shows my noobness :)

Status
------

As far as I remember it worked fairly reliably, but I'm sure it has a couple of security holes. It was intended as a learning exercise and it isn't production-ready.

Plans
-----

My intention is to fix any problems and clean up the code (Dec 2010). However, this is really low-priority.
